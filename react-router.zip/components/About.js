function About() {
  return <h1>This is About page</h1>;
}

export default About;
