function Contact() {
  return <h1>This is Contact page</h1>;
}

export default Contact;
