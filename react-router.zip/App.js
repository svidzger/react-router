import "./App.css";
import NavBar from "./components/NavBar.js";

function App() {
  return (
    <NavBar/>
  );
}

export default App;
